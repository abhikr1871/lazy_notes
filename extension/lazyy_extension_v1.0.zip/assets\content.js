console.log("Lazzy Content Script Loaded");const L=window.location.hostname.includes("youtube.com"),y=window.location.hostname.includes("leetcode.com"),x=window.location.hostname.includes("codeforces.com");function B(){const r=document.querySelector("#secondary-inner")||document.querySelector("ytd-watch-flexy #secondary")||document.querySelector("#secondary");let o=document.getElementById("lazyy-sidebar-yt");if(r)if(o){o.parentElement!==r&&r.insertBefore(o,r.firstChild);const t=o.style.display==="none"||window.getComputedStyle(o).display==="none";o.style.display=t?"block":"none";return}else{o=document.createElement("iframe"),o.id="lazyy-sidebar-yt",o.src=chrome.runtime.getURL("sidepanel.html?context=youtube"),o.style.cssText=`
                width: 100%; 
                height: 600px; 
                border: none; 
                border-radius: 12px; 
                margin-bottom: 16px; 
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                z-index: 999;
                display: block;
            `,r.insertBefore(o,r.firstChild);return}let e=document.getElementById("lazyy-youtube-container");if(e)e.classList.toggle("lazyy-visible");else{e=document.createElement("div"),e.id="lazyy-youtube-container",e.style.cssText=`
            position: fixed; top: 0; right: -420px; width: 420px; height: 100vh;
            z-index: 999999; transition: right 0.3s ease; box-shadow: -5px 0 25px rgba(0,0,0,0.15);
        `;const t=document.createElement("iframe");t.src=chrome.runtime.getURL("sidepanel.html?context=youtube"),t.style.cssText="width: 100%; height: 100%; border: none;";const n=document.createElement("button");n.innerHTML="✕",n.style.cssText="position: absolute; left: -30px; top: 20px; width: 30px; height: 30px; background: white; border: 1px solid #eee; border-radius: 5px 0 0 5px; cursor: pointer; font-weight: bold; color: #666;",n.onclick=()=>e.classList.remove("lazyy-visible"),e.appendChild(n),e.appendChild(t),document.body.appendChild(e);const i=document.createElement("style");i.textContent="#lazyy-youtube-container.lazyy-visible { right: 0 !important; }",document.head.appendChild(i),setTimeout(()=>e.classList.add("lazyy-visible"),10)}}function I(){const r=["ytd-watch-metadata #owner","ytd-watch-metadata #actions-inner","ytd-watch-metadata #top-row","#subscribe-button","#owner"];let o=null;for(const t of r){const n=document.querySelector(t);if(n){o=n;break}}if(!o)return;let e=document.getElementById("lazyy-notes-button");if(e){e.parentElement!==o&&o.appendChild(e);return}e=document.createElement("button"),e.id="lazyy-notes-button",e.innerHTML="🦉 Open Lazzy",e.style.cssText=`
        background: linear-gradient(135deg, #7c3aed 0%, #db2777 100%);
        color: white; border: 1px solid rgba(255,255,255,0.2); 
        padding: 8px 16px; margin-left: 10px; border-radius: 20px; 
        font-weight: 600; cursor: pointer; font-size: 13px;
        box-shadow: 0 4px 6px -1px rgba(99, 102, 241, 0.3);
        transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 6px;
        position: relative; z-index: 9999;
    `,e.onclick=t=>{t.preventDefault(),t.stopPropagation(),B()},o.appendChild(e)}function T(r){let o=document.getElementById("lazyy-leetcode-container");if(o)o.classList.toggle("lazyy-visible"),o.classList.contains("lazyy-visible")&&r&&chrome.runtime.sendMessage({action:"switchLeetCodeTab",tab:r});else{o=document.createElement("div"),o.id="lazyy-leetcode-container",o.style.cssText=`
            position: fixed; top: 0; right: -420px; width: 400px; height: 100vh;
            background: white; z-index: 10000; transition: right 0.3s ease;
            box-shadow: -5px 0 15px rgba(0,0,0,0.1); border-left: 1px solid #eee;
            display: flex; flex-direction: column;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
        `;const e=document.createElement("iframe"),t=r?chrome.runtime.getURL("sidepanel.html?context=leetcode&tab="+r):chrome.runtime.getURL("sidepanel.html?context=leetcode");e.src=t,e.style.cssText=`
            width: 100%; height: 100%; border: none;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
        `;const n=document.createElement("button");n.innerHTML="✕",n.style.cssText=`
            position: absolute; left: -30px; top: 20px; width: 30px; height: 30px;
            background: white; border: 1px solid #eee; border-radius: 5px 0 0 5px;
            cursor: pointer; font-weight: bold; color: #666;
        `,n.onclick=()=>o.classList.remove("lazyy-visible"),o.appendChild(n),o.appendChild(e),document.body.appendChild(o);const i=document.createElement("style");i.textContent=`
            #lazyy-leetcode-container.lazyy-visible { right: 0 !important; }
        `,document.head.appendChild(i),setTimeout(()=>{o.classList.add("lazyy-visible"),r&&chrome.runtime.sendMessage({action:"switchLeetCodeTab",tab:r})},10)}}function v(){if(document.querySelector(".text-difficulty-easy"))return"Easy";if(document.querySelector(".text-difficulty-medium"))return"Medium";if(document.querySelector(".text-difficulty-hard"))return"Hard";if(document.querySelector(".text-green-500")||document.querySelector(".text-olive")||document.querySelector(".text-teal-500"))return"Easy";if(document.querySelector(".text-yellow-500")||document.querySelector(".text-amber-500")||document.querySelector(".text-yellow"))return"Medium";if(document.querySelector(".text-red-500")||document.querySelector(".text-pink-500")||document.querySelector(".text-pink"))return"Hard";const r=document.querySelectorAll("div, span, p");for(const o of r){if(o.innerText==="Easy"&&(o.className.includes("text-")||o.className.includes("color-")))return"Easy";if(o.innerText==="Medium"&&(o.className.includes("text-")||o.className.includes("color-")))return"Medium";if(o.innerText==="Hard"&&(o.className.includes("text-")||o.className.includes("color-")))return"Hard"}for(const o of r){if(o.innerText==="Hard")return"Hard";if(o.innerText==="Medium")return"Medium";if(o.innerText==="Easy")return"Easy"}return"Medium"}function H(){const r=window.location.pathname;if(!r.startsWith("/problems/")||r.includes("/problemset")||document.getElementById("lazyy-lc-plus-btn"))return;const o=['div[data-cy="question-title"]',".text-title-large","span.text-2xl",".mr-2.text-xl","div.flex.items-center div.text-title-large"];let e=null;for(const t of o){const n=document.querySelectorAll(t);for(const i of n)if(i.innerText&&i.innerText.length>5){e=i;break}if(e)break}if(e){const t=v();let n="#ffa116";t==="Easy"?n="#00b8a3":t==="Hard"&&(n="#ff375f");const i=document.createElement("button");i.id="lazyy-lc-plus-btn",i.innerHTML=`
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 6px;">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
                <polyline points="10 9 9 9 8 9"></polyline>
            </svg>
            Notes
        `,i.title="View Notes",i.style.cssText=`
            margin-left: 12px;
            padding: 6px 14px;
            border-radius: 20px;
            background-color: #2d2d2d;
            color: ${n};
            border: 1px solid rgba(255,255,255,0.1);
            font-size: 13px;
            font-weight: 700;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            line-height: 1;
            transition: all 0.2s ease;
            vertical-align: middle;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        `,i.onclick=s=>{s.preventDefault(),s.stopPropagation(),T("notes")};const l=document.createElement("button");l.id="lazyy-lc-ai-btn",l.innerHTML="✨ AI",l.title="Generate AI Problem Breakdown",l.style.cssText=`
            margin-left: 8px;
            padding: 6px 14px;
            border-radius: 20px;
            background: linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%);
            color: #ffffff;
            border: 1px solid rgba(255,255,255,0.2);
            font-size: 13px;
            font-weight: 700;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            line-height: 1;
            white-space: nowrap;
            transition: all 0.2s ease;
            vertical-align: middle;
            box-shadow: 0 2px 6px rgba(124, 58, 237, 0.4);
        `,l.onmouseover=()=>{l.style.transform="translateY(-1px)",l.style.boxShadow="0 4px 10px rgba(124, 58, 237, 0.6)"},l.onmouseout=()=>{l.style.transform="translateY(0)",l.style.boxShadow="0 2px 6px rgba(124, 58, 237, 0.4)"},l.onclick=s=>{s.preventDefault(),s.stopPropagation(),T("ai")},window.getComputedStyle(e).display!=="flex"&&(e.style.display="inline-flex"),e.style.alignItems="center",e.appendChild(i),e.appendChild(l)}}function p(r){let o=document.getElementById("lazyy-codeforces-container");if(o)o.classList.toggle("lazyy-visible");else{o=document.createElement("div"),o.id="lazyy-codeforces-container",o.style.cssText=`
            position: fixed; top: 0; right: 0; width: 400px; height: 100vh;
            background: white; z-index: 10000; transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: -5px 0 25px rgba(0,0,0,0.15); border-left: 1px solid #eee;
            display: flex; flex-direction: column;
            border-top-left-radius: 12px;
            border-bottom-left-radius: 12px;
            transform: translateX(105%);
        `,chrome.storage.local.get(["lazyy_cf_width"],a=>{a.lazyy_cf_width&&(o.style.width=a.lazyy_cf_width)});const e=document.createElement("iframe"),t=r?chrome.runtime.getURL("sidepanel.html?context=codeforces&tab="+r):chrome.runtime.getURL("sidepanel.html?context=codeforces");e.src=t,e.style.cssText=`
            width: 100%; height: 100%; border: none;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
        `;const n=document.createElement("button");n.innerHTML="✕",n.style.cssText=`
            position: absolute; left: -30px; top: 20px; width: 30px; height: 30px;
            background: white; border: 1px solid #eee; border-radius: 5px 0 0 5px;
            cursor: pointer; font-weight: bold; color: #666;
        `,n.onclick=()=>o.classList.remove("lazyy-visible");const i=document.createElement("div");i.className="lazyy-resizer",i.style.cssText=`
            position: absolute; left: 0; top: 0; width: 6px; height: 100%;
            cursor: ew-resize; z-index: 10001; background: transparent;
            transition: background 0.2s; border-top-left-radius: 12px; border-bottom-left-radius: 12px;
        `,i.addEventListener("mousedown",a=>{a.preventDefault();const s=a.clientX,d=parseInt(document.defaultView.getComputedStyle(o).width,10);o.style.transition="none",e.style.pointerEvents="none",i.style.background="rgba(99, 102, 241, 0.8)";const u=z=>{const m=d-(z.clientX-s);m>350&&m<window.innerWidth*.8&&(o.style.width=m+"px")},c=()=>{o.style.transition="transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)",e.style.pointerEvents="auto",i.style.background="transparent",document.removeEventListener("mousemove",u),document.removeEventListener("mouseup",c),chrome.storage.local.set({lazyy_cf_width:o.style.width})};document.addEventListener("mousemove",u),document.addEventListener("mouseup",c)}),i.onmouseover=()=>{e.style.pointerEvents!=="none"&&(i.style.background="rgba(99, 102, 241, 0.4)")},i.onmouseout=()=>{e.style.pointerEvents!=="none"&&(i.style.background="transparent")},o.appendChild(i),o.appendChild(n),o.appendChild(e),document.body.appendChild(o);const l=document.createElement("style");l.textContent=`
            #lazyy-codeforces-container.lazyy-visible { transform: translateX(0) !important; }
        `,document.head.appendChild(l),setTimeout(()=>o.classList.add("lazyy-visible"),10)}}function U(){if(document.getElementById("lazyy-cf-btn"))return;const r=[".problem-statement .header .title",".problem-statement .header","#pageContent .title","div.title"];let o=null;for(const e of r){const t=document.querySelector(e);if(t){o=t;break}}if(o){const e=document.createElement("a");e.id="lazyy-cf-btn",e.innerHTML="🦉 Notes",e.style.cssText=`
            margin-left: 12px;
            padding: 5px 14px;
            border-radius: 20px;
            background: linear-gradient(135deg, #3b8ea5 0%, #2b6e85 100%);
            color: white;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 2px 4px rgba(0,0,0,0.15);
            vertical-align: middle;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            position: relative; 
            z-index: 100;
            border: 1px solid rgba(255,255,255,0.2);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            text-decoration: none;
            line-height: 1.2;
            transition: all 0.2s ease;
        `,e.onmouseover=()=>{e.style.transform="translateY(-1px)",e.style.boxShadow="0 4px 8px rgba(0,0,0,0.2)",e.style.filter="brightness(1.1)"},e.onmouseout=()=>{e.style.transform="translateY(0)",e.style.boxShadow="0 2px 4px rgba(0,0,0,0.15)",e.style.filter="none"},e.onclick=t=>{t.preventDefault(),t.stopPropagation(),console.log("Lazzy: Toggling Codeforces sidebar");const n=document.getElementById("lazyy-codeforces-container");(!n||!n.classList.contains("lazyy-visible"))&&p(),setTimeout(()=>{chrome.runtime.sendMessage({action:"resetToTopics"})},100)},o.appendChild(e),console.log("Lazzy: Codeforces button injected successfully")}else{const e=document.querySelector("#sidebar");if(e){const t=document.createElement("div");t.id="lazyy-cf-btn",t.innerHTML="🦉 Lazzy Notes",t.style.cssText=`
                margin: 15px 0;
                padding: 12px;
                background: white;
                border-radius: 8px;
                border: 1px solid #e1e1e1;
                text-align: center;
                cursor: pointer;
                color: #3b8ea5;
                font-weight: bold;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
                transition: all 0.2s ease;
            `,t.onmouseover=()=>{t.style.transform="translateY(-1px)",t.style.boxShadow="0 4px 8px rgba(0,0,0,0.1)"},t.onmouseout=()=>{t.style.transform="translateY(0)",t.style.boxShadow="0 2px 5px rgba(0,0,0,0.05)"},t.onclick=p,e.insertBefore(t,e.firstChild),console.log("Lazzy: Codeforces button injected into sidebar")}else{const t=document.createElement("button");t.id="lazyy-cf-btn",t.innerHTML="🦉 Notes",t.style.cssText=`
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: linear-gradient(135deg, #3b8ea5 0%, #2b6e85 100%);
                color: white;
                border: none;
                border-radius: 30px;
                padding: 12px 24px;
                font-weight: bold;
                font-size: 14px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                z-index: 10001;
                cursor: pointer;
                transition: transform 0.2s, box-shadow 0.2s;
            `,t.onmouseover=()=>{t.style.transform="scale(1.05)",t.style.boxShadow="0 6px 16px rgba(0,0,0,0.35)"},t.onmouseout=()=>{t.style.transform="scale(1)",t.style.boxShadow="0 4px 12px rgba(0,0,0,0.3)"},t.onclick=p,document.body.appendChild(t),console.log("Lazzy: Codeforces floating button injected")}}}function _(){if(document.getElementById("lazyy-cf-compile-btn"))return;const r=[".problem-statement .header .title",".problem-statement .header","#pageContent .title","div.title"];let o=null;for(const e of r){const t=document.querySelector(e);if(t){o=t;break}}if(o){const e=document.createElement("a");e.id="lazyy-cf-compile-btn",e.innerHTML="⚡ Code",e.style.cssText=`
            margin-left: 8px;
            padding: 5px 14px;
            border-radius: 20px;
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            color: white;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 2px 4px rgba(0,0,0,0.15);
            vertical-align: middle;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            position: relative; 
            z-index: 100;
            border: 1px solid rgba(255,255,255,0.2);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            text-decoration: none;
            line-height: 1.2;
            transition: all 0.2s ease;
        `,e.onmouseover=()=>{e.style.transform="translateY(-1px)",e.style.boxShadow="0 4px 8px rgba(0,0,0,0.2)",e.style.filter="brightness(1.1)"},e.onmouseout=()=>{e.style.transform="translateY(0)",e.style.boxShadow="0 2px 4px rgba(0,0,0,0.15)",e.style.filter="none"},e.onclick=t=>{t.preventDefault(),t.stopPropagation();const n=document.getElementById("lazyy-codeforces-container");(!n||!n.classList.contains("lazyy-visible"))&&p("code"),setTimeout(()=>{chrome.runtime.sendMessage({action:"switchCodeforcesTab",tab:"code"})},100)},o.appendChild(e)}}function D(){if(document.getElementById("lazyy-cf-ai-btn"))return;const r=[".problem-statement .header .title",".problem-statement .header","#pageContent .title","div.title"];let o=null;for(const e of r){const t=document.querySelector(e);if(t){o=t;break}}if(o){const e=document.createElement("a");e.id="lazyy-cf-ai-btn",e.innerHTML="✨ AI",e.title="Generate AI Problem Breakdown",e.style.cssText=`
            margin-left: 8px;
            padding: 5px 14px;
            border-radius: 20px;
            background: linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%);
            color: #ffffff;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 2px 6px rgba(124, 58, 237, 0.4);
            vertical-align: middle;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            position: relative; 
            z-index: 100;
            border: 1px solid rgba(255,255,255,0.2);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            text-decoration: none;
            line-height: 1.2;
            white-space: nowrap;
            transition: all 0.2s ease;
        `,e.onmouseover=()=>{e.style.transform="translateY(-1px)",e.style.boxShadow="0 4px 10px rgba(124, 58, 237, 0.6)",e.style.filter="brightness(1.1)"},e.onmouseout=()=>{e.style.transform="translateY(0)",e.style.boxShadow="0 2px 6px rgba(124, 58, 237, 0.4)",e.style.filter="none"},e.onclick=t=>{t.preventDefault(),t.stopPropagation();const n=document.getElementById("lazyy-codeforces-container");(!n||!n.classList.contains("lazyy-visible"))&&p("ai"),setTimeout(()=>{chrome.runtime.sendMessage({action:"switchCodeforcesTab",tab:"ai"})},100)},o.appendChild(e)}}const g=window.location.hostname.includes("geeksforgeeks.org");function Y(){if(!window.location.pathname.includes("/problems/")||document.getElementById("lazyy-gfg-ai-btn"))return;const o=[".problems_header_content__title",'div[class*="problems_header_content__title"]',".problem-statement_header__","h3",".header-title"];let e=null;for(const i of o){const l=document.querySelector(i);if(l){e=l.parentElement||l;break}}const t=document.createElement("button");t.id="lazyy-gfg-ai-btn",t.innerHTML="✨ AI",t.style.cssText="margin-left: 10px; padding: 4px 10px; background: linear-gradient(135deg, #4f46e5, #7c3aed); color: white; border: none; border-radius: 8px; font-weight: bold; font-size: 11px; cursor: pointer; box-shadow: 0 2px 6px rgba(79, 70, 229, 0.3); font-family: system-ui, -apple-system, sans-serif; transition: all 0.2s ease; vertical-align: middle;",t.onmouseover=()=>t.style.transform="scale(1.05)",t.onmouseout=()=>t.style.transform="scale(1)",t.onclick=i=>{i.preventDefault(),i.stopPropagation(),E("ai")};const n=document.createElement("button");if(n.id="lazyy-gfg-notes-btn",n.innerHTML="📝 Notes",n.style.cssText="margin-left: 6px; padding: 4px 10px; background: #0f172a; color: white; border: 1px solid #334155; border-radius: 8px; font-weight: bold; font-size: 11px; cursor: pointer; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2); font-family: system-ui, -apple-system, sans-serif; transition: all 0.2s ease; vertical-align: middle;",n.onmouseover=()=>n.style.transform="scale(1.05)",n.onmouseout=()=>n.style.transform="scale(1)",n.onclick=i=>{i.preventDefault(),i.stopPropagation(),E("code")},e)e.appendChild(t),e.appendChild(n);else{const i=document.createElement("div");i.id="lazyy-gfg-ai-btn-container",i.style.cssText="position: fixed; top: 65px; right: 20px; z-index: 999999; display: flex; flex-direction: row; gap: 8px;",i.appendChild(t),i.appendChild(n),document.body.appendChild(i)}}function E(r){let o=document.getElementById("lazyy-gfg-container");if(o){const e=o.querySelector("iframe");e&&r&&(e.src=chrome.runtime.getURL("sidepanel.html?context=gfg&tab="+r)),o.classList.add("lazyy-visible")}else{o=document.createElement("div"),o.id="lazyy-gfg-container",o.style.cssText=`
            position: fixed; top: 0; right: -420px; width: 420px; height: 100vh;
            z-index: 999999; transition: right 0.3s ease; box-shadow: -5px 0 25px rgba(0,0,0,0.15);
        `;const e=document.createElement("iframe"),t=r?chrome.runtime.getURL("sidepanel.html?context=gfg&tab="+r):chrome.runtime.getURL("sidepanel.html?context=gfg");e.src=t,e.style.cssText="width: 100%; height: 100%; border: none;";const n=document.createElement("button");n.innerHTML="✕",n.style.cssText="position: absolute; left: -30px; top: 20px; width: 30px; height: 30px; background: white; border: 1px solid #eee; border-radius: 5px 0 0 5px; cursor: pointer; font-weight: bold; color: #666;",n.onclick=()=>o.classList.remove("lazyy-visible"),o.appendChild(n),o.appendChild(e),document.body.appendChild(o);const i=document.createElement("style");i.textContent="#lazyy-gfg-container.lazyy-visible { right: 0 !important; }",document.head.appendChild(i),setTimeout(()=>o.classList.add("lazyy-visible"),10)}}function P(){return!!(document.querySelector(".monaco-editor")||document.querySelector(".ace_editor")||document.querySelector(".CodeMirror")||document.querySelector("pre code")||document.querySelector("textarea.code")||document.querySelector('textarea[name*="code"]'))}function N(){const r=window.location.hostname.toLowerCase();return!(["google.com","google.co.in","bing.com","duckduckgo.com","yahoo.com","baidu.com","yandex.com","search.yahoo.com"].some(e=>r.endsWith(e)||r===e)||window.location.protocol.startsWith("chrome")||window.location.protocol.startsWith("edge"))}function M(){if(y||x||g||L||!N()||document.getElementById("lazyy-universal-floating-stack"))return;const r=P(),o=localStorage.getItem("lazyy_stack_top")||"35%",e=document.createElement("div");e.id="lazyy-universal-floating-stack",e.style.cssText=`
        position: fixed;
        right: 14px;
        top: ${o};
        z-index: 999999;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
        background: rgba(15, 23, 42, 0.9);
        backdrop-filter: blur(12px);
        padding: 8px 6px;
        border-radius: 28px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(99, 102, 241, 0.3);
        transition: box-shadow 0.2s ease, transform 0.1s ease;
        user-select: none;
        touch-action: none;
    `;const t=document.createElement("div");t.title="Drag Lazzy Widget | Click to open notes",t.style.cssText=`
        width: 38px; height: 38px; border-radius: 50%;
        background: linear-gradient(135deg, #4f46e5, #7c3aed);
        display: flex; align-items: center; justify-content: center;
        cursor: grab; box-shadow: 0 4px 14px rgba(79, 70, 229, 0.5);
        border: 2px solid rgba(255, 255, 255, 0.2); transition: all 0.2s ease;
        position: relative;
    `;const n=document.createElement("img");n.src=chrome.runtime.getURL("icons/icon48.png"),n.style.cssText="width: 24px; height: 24px; border-radius: 50%; pointer-events: none;",t.appendChild(n);let i=!1,l=0,a=0;const s=c=>{i=!1,l=c.clientY||c.touches&&c.touches[0].clientY,a=e.getBoundingClientRect().top;const m=h=>{const S=(h.clientY||h.touches&&h.touches[0].clientY)-l;if(Math.abs(S)>4){i=!0,t.style.cursor="grabbing";let b=a+S;const q=window.innerHeight-e.offsetHeight-10;b=Math.max(10,Math.min(q,b)),e.style.top=`${b}px`}},f=()=>{window.removeEventListener("mousemove",m),window.removeEventListener("mouseup",f),window.removeEventListener("touchmove",m),window.removeEventListener("touchend",f),t.style.cursor="grab",i&&localStorage.setItem("lazyy_stack_top",e.style.top)};window.addEventListener("mousemove",m),window.addEventListener("mouseup",f),window.addEventListener("touchmove",m),window.addEventListener("touchend",f)};t.addEventListener("mousedown",s),t.addEventListener("touchstart",s),t.onclick=c=>{i||(c.preventDefault(),c.stopPropagation(),w(r?"code":"notes"))};const d=document.createElement("button");d.innerHTML="✨",d.title="Ask Lazzy AI Explainer",d.style.cssText=`
        width: 34px; height: 34px; border-radius: 50%;
        background: linear-gradient(135deg, #6366f1, #a855f7);
        color: white; border: none; font-size: 15px; cursor: pointer;
        display: flex; items-center; justify-content: center;
        box-shadow: 0 4px 10px rgba(99, 102, 241, 0.4); transition: transform 0.2s ease;
    `,d.onmouseover=()=>d.style.transform="scale(1.15)",d.onmouseout=()=>d.style.transform="scale(1)",d.onclick=c=>{c.preventDefault(),c.stopPropagation(),w("ai")};const u=document.createElement("button");u.innerHTML="📝",u.title="Open Smart Notes",u.style.cssText=`
        width: 34px; height: 34px; border-radius: 50%;
        background: #1e293b; color: white; border: 1px solid rgba(255, 255, 255, 0.2);
        font-size: 14px; cursor: pointer; display: flex; items-center; justify-content: center;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3); transition: transform 0.2s ease;
    `,u.onmouseover=()=>u.style.transform="scale(1.15)",u.onmouseout=()=>u.style.transform="scale(1)",u.onclick=c=>{c.preventDefault(),c.stopPropagation(),w(r?"code":"notes")},e.appendChild(t),e.appendChild(d),e.appendChild(u),document.body.appendChild(e)}function w(r){let o=document.getElementById("lazyy-universal-container");if(o){const e=o.querySelector("iframe");e&&r&&(e.src=chrome.runtime.getURL("sidepanel.html?context=universal&tab="+r)),o.classList.add("lazyy-visible")}else{o=document.createElement("div"),o.id="lazyy-universal-container",o.style.cssText=`
            position: fixed; top: 0; right: -420px; width: 420px; height: 100vh;
            z-index: 999999; transition: right 0.3s ease; box-shadow: -5px 0 25px rgba(0,0,0,0.15);
        `;const e=document.createElement("iframe"),t=r?chrome.runtime.getURL("sidepanel.html?context=universal&tab="+r):chrome.runtime.getURL("sidepanel.html?context=universal");e.src=t,e.style.cssText="width: 100%; height: 100%; border: none;";const n=document.createElement("button");n.innerHTML="✕",n.style.cssText="position: absolute; left: -30px; top: 20px; width: 30px; height: 30px; background: white; border: 1px solid #eee; border-radius: 5px 0 0 5px; cursor: pointer; font-weight: bold; color: #666;",n.onclick=()=>o.classList.remove("lazyy-visible"),o.appendChild(n),o.appendChild(e),document.body.appendChild(o);const i=document.createElement("style");i.textContent="#lazyy-universal-container.lazyy-visible { right: 0 !important; }",document.head.appendChild(i),setTimeout(()=>o.classList.add("lazyy-visible"),10)}}const j=new MutationObserver(()=>{L&&window.location.href.includes("youtube.com/watch")&&I(),y&&window.location.href.includes("leetcode.com/problems")&&H(),x&&(window.location.href.includes("/problem/")||window.location.href.includes("/problemset/"))&&(U(),_(),D()),g&&window.location.href.includes("/problems/")&&Y(),!y&&!x&&!g&&M()});j.observe(document.body,{childList:!0,subtree:!0});!y&&!x&&!g&&setInterval(()=>{M()},1e3);function C(){try{const o=document.querySelectorAll(".monaco-editor .view-line");if(o&&o.length>0){const e=[];o.forEach(n=>e.push(n.innerText));const t=e.join(`
`);if(t.trim().length>0)return t}}catch{}const r=document.querySelector("textarea.inputarea")||document.querySelector("textarea");return r&&r.value?r.value:""}function k(){const r=document.querySelector("#source")||document.querySelector('textarea[name="source"]');if(r&&r.value)return r.value;const o=document.querySelectorAll(".ace_line");if(o&&o.length>0){const e=[];return o.forEach(t=>e.push(t.innerText)),e.join(`
`)}return""}chrome.runtime.onMessage.addListener((r,o,e)=>{if(r.action==="getYoutubeContext")return e({url:window.location.href,title:document.title}),!0;if(r.action==="getPageText"&&e({text:document.body.innerText}),r.action==="getVideoTime"){const t=document.querySelector("video");e({time:t?new Date(t.currentTime*1e3).toISOString().substring(14,19):null,seconds:t?Math.floor(t.currentTime):0})}if(r.action==="seekVideoTime"){const t=document.querySelector("video");if(t){let n=r.seconds;if(n===void 0&&r.timeStr){const i=r.timeStr.replace("[","").replace("]","").split(":").map(Number);i.length===2?n=i[0]*60+i[1]:i.length===3&&(n=i[0]*3600+i[1]*60+i[2])}n!==void 0?(t.currentTime=n,t.play(),e({success:!0,currentTime:t.currentTime})):e({success:!1,error:"Invalid seconds"})}else e({success:!1,error:"No video found"});return!0}if(r.action==="captureVideoFrame"){const t=document.querySelector("video");if(t)try{const n=document.createElement("canvas");n.width=t.videoWidth,n.height=t.videoHeight,n.getContext("2d").drawImage(t,0,0,n.width,n.height),e({success:!0,imageData:n.toDataURL("image/jpeg",.8),time:new Date(t.currentTime*1e3).toISOString().substring(14,19)})}catch(n){e({success:!1,error:n.toString()})}else e({success:!1,error:"No video found"});return!0}if(r.action==="getLeetCodeProblemDetails"){const t=['div[data-cy="question-title"]',".text-title-large","span.text-2xl",".mr-2.text-xl","div.flex.items-center div.text-title-large",'a[href^="/problems/"]'];let n="Unknown Problem";for(const l of t){const a=document.querySelector(l);if(a&&a.innerText&&a.innerText.length>5){n=a.innerText;break}}const i=v();return e({title:n,difficulty:i,url:window.location.href,code:C()}),!0}if(r.action==="getCodeforcesProblemDetails"){const t=document.querySelector(".problem-statement .header .title");let n=t?t.innerText:"Unknown Problem",i="Unrated",l=0,a=[];const s=document.querySelectorAll(".tag-box");for(const d of s)if(d.title==="Difficulty"){const u=d.innerText.trim(),c=parseInt(u.replace("*",""));isNaN(c)||(l=c,i=c.toString())}else a.push(d.innerText.trim());return e({title:n,difficulty:i,url:window.location.href,rating:l,tags:a,code:k()}),!0}if(r.action==="getGFGProblemDetails"){let t="Unknown Problem";const n=document.querySelector("h3")||document.querySelector(".header-title")||document.querySelector("h1");return n&&n.innerText&&(t=n.innerText.trim()),e({title:t,difficulty:"Medium",url:window.location.href,code:getGFGCode()}),!0}if(r.action==="getUniversalProblemDetails"){const t=window.location.href;let n="Web Note",i=document.title||"Untitled Note",l="Medium",a="";if(t.includes("leetcode.com/problems")){n="LeetCode";const s=document.querySelector('div[data-cy="question-title"]')||document.querySelector(".text-title-large")||document.querySelector("h1");s&&s.innerText&&(i=s.innerText.trim()),l=v(),a=C()}else if(t.includes("codeforces.com")){n="Codeforces";const s=document.querySelector(".problem-statement .header .title");s&&s.innerText&&(i=s.innerText.trim()),a=k()}else if(t.includes("geeksforgeeks.org")){n="GeeksforGeeks";const s=document.querySelector("h3")||document.querySelector(".header-title")||document.querySelector("h1");s&&s.innerText&&(i=s.innerText.trim()),a=getGFGCode()}else if(t.includes("hackerrank.com")){n="HackerRank";const s=document.querySelector("h1")||document.querySelector(".page-label");s&&s.innerText&&(i=s.innerText.trim());const d=document.querySelectorAll(".monaco-editor .view-line");d.length>0&&(a=Array.from(d).map(u=>u.innerText).join(`
`))}else if(t.includes("youtube.com/watch")){n="YouTube";const s=document.querySelector("h1.ytd-watch-metadata")||document.querySelector("title");s&&s.innerText&&(i=s.innerText.replace("- YouTube","").trim())}else{const s=window.getSelection()?window.getSelection().toString():"";s&&(a=s)}return e({platform:n,title:i,difficulty:l,url:t,code:a}),!0}return!0});
